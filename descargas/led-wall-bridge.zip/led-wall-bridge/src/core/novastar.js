// Protocolo de control central NovaStar (VX1000 / VX600 / VX16s / NovaPro UHD Jr / MCTRL4K).
// Trama de petición:  55 aa | ack | label | src=fe | dest | devType | port | board(2) | code | 00 | addr(4) | len(2) | data | sum(2)
// Trama de respuesta: aa 55 | ack | label | src | dest=fe | ... | addr(4) | len(2) | data | sum(2)
// sum = (suma de bytes desde el índice 2 hasta el último dato + 0x5555) & 0xffff, little-endian.

export const NOVA_TCP_PORT = 5200;
export const NOVA_UDP_SEARCH_PORT = 3800;
export const NOVA_SEARCH_REQUEST = 'rqProMI:';
export const NOVA_SEARCH_REPLY_PREFIX = 'rpProMI:';

const HEADER_LEN = 18;
const FRAME_OVERHEAD = HEADER_LEN + 2;
const ADDR_PC = 0xfe;

export const REG = {
  modelId: 0x00000002,
  brightness: 0x02000001,
  displayMode: 0x13000004,
  inputInfo: 0x13010001,
  layerSourceBase: 0x13020012,
  layerStride: 0x30,
  preset: 0x13510100,
  backupA: 0x02000018,
  backupB: 0x02000098,
  backupC: 0x02000100,
};

export const DISPLAY_MODES = [
  { id: 'normal', label: 'Normal', code: 0x03, icon: 'play' },
  { id: 'freeze', label: 'Congelar', code: 0x04, icon: 'pause' },
  { id: 'ftb', label: 'Negro (FTB)', code: 0x05, icon: 'moon' },
];

export const TEST_PATTERNS = [
  { code: 0x01, label: 'Rojo', color: '#FF2D2D' },
  { code: 0x02, label: 'Verde', color: '#22D46B' },
  { code: 0x03, label: 'Azul', color: '#2F6BFF' },
  { code: 0x04, label: 'Blanco', color: '#FFFFFF' },
  { code: 0x00, label: 'Negro', color: '#000000' },
  { code: 0x05, label: 'Barras V', color: null },
  { code: 0x06, label: 'Barras H', color: null },
  { code: 0x07, label: 'Ajedrez', color: null },
  { code: 0x12, label: 'Diagonales', color: null },
];

export const INPUT_SLOTS = [
  { code: 0x00, label: 'HDMI 1' },
  { code: 0x01, label: 'HDMI 2' },
  { code: 0x02, label: 'DVI 1' },
  { code: 0x03, label: 'DVI 2' },
  { code: 0x04, label: 'SDI' },
  { code: 0x05, label: 'OPT 1' },
  { code: 0x06, label: 'OPT 2' },
  { code: 0x07, label: 'Mosaico' },
];

export const PRESET_COUNT = 10;
export const LAYER_COUNT = 3;

export const CONTROL_MODELS = [
  { id: 'vx1000', label: 'NovaStar VX1000', layers: true, backup: true },
  { id: 'vx600', label: 'NovaStar VX600', layers: true, backup: true },
  { id: 'vx16s', label: 'NovaStar VX16s', layers: true, backup: true },
  { id: 'uhdjr', label: 'NovaPro UHD Jr', layers: true, backup: false },
  { id: 'mctrl4k', label: 'NovaStar MCTRL4K', layers: false, backup: false },
  { id: 'other', label: 'Otro (protocolo central)', layers: true, backup: false },
];

const u16le = (n) => [n & 0xff, (n >>> 8) & 0xff];
const u32le = (n) => [n & 0xff, (n >>> 8) & 0xff, (n >>> 16) & 0xff, (n >>> 24) & 0xff];
const readU16 = (b, i) => b[i] | (b[i + 1] << 8);
const readU32 = (b, i) => (b[i] | (b[i + 1] << 8) | (b[i + 2] << 16) | (b[i + 3] << 24)) >>> 0;

export function checksum(bytes, from = 2, to = bytes.length) {
  let sum = 0x5555;
  for (let i = from; i < to; i++) sum += bytes[i];
  return u16le(sum & 0xffff);
}

export function buildFrame({ address, data = [], length, write = true, dest = 0x00, devType = 0x00, port = 0x00, board = 0x0000, label = 0 }) {
  const len = length ?? data.length;
  const head = [0x55, 0xaa, 0x00, label & 0xff, ADDR_PC, dest, devType, port, ...u16le(board), write ? 0x01 : 0x00, 0x00, ...u32le(address), ...u16le(len)];
  const body = [...head, ...data];
  return [...body, ...checksum(body)];
}

export function toHex(bytes) {
  return Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join(' ');
}

export function fromHex(str) {
  const clean = String(str || '').replace(/0x/gi, '').replace(/[^0-9a-f]/gi, '');
  if (clean.length % 2) throw new Error('Hex con número impar de dígitos');
  const out = [];
  for (let i = 0; i < clean.length; i += 2) out.push(parseInt(clean.slice(i, i + 2), 16));
  return out;
}

// Extrae la primera trama de respuesta completa de un buffer de bytes (stream TCP).
// Devuelve { frame, rest } o null si aún faltan bytes.
export function extractFrame(buffer) {
  const b = Array.from(buffer);
  let start = -1;
  for (let i = 0; i + 1 < b.length; i++) {
    if (b[i] === 0xaa && b[i + 1] === 0x55) { start = i; break; }
  }
  if (start < 0) return null;
  const view = b.slice(start);
  if (view.length < FRAME_OVERHEAD) return null;
  const total = FRAME_OVERHEAD + readU16(view, 16);
  if (view.length < total) return null;
  return { frame: view.slice(0, total), rest: view.slice(total) };
}

export function parseResponse(bytes) {
  const b = Array.from(bytes);
  if (b.length < FRAME_OVERHEAD || b[0] !== 0xaa || b[1] !== 0x55) {
    return { ok: false, error: 'Respuesta sin cabecera aa 55' };
  }
  const len = readU16(b, 16);
  if (b.length < FRAME_OVERHEAD + len) return { ok: false, error: 'Respuesta incompleta' };
  const end = HEADER_LEN + len;
  const [lo, hi] = checksum(b, 2, end);
  const checksumOk = b[end] === lo && b[end + 1] === hi;
  const ack = b[2];
  return {
    ok: checksumOk && ack === 0,
    checksumOk,
    ack,
    label: b[3],
    write: b[10] === 1,
    address: readU32(b, 12),
    length: len,
    data: b.slice(HEADER_LEN, end),
    error: !checksumOk ? 'Checksum inválido' : ack !== 0 ? `El equipo rechazó el comando (ack 0x${ack.toString(16)})` : null,
  };
}

// Respuesta que generaría el equipo para una petición (simulador y modo demo del puente).
export function buildResponse(request, data = []) {
  const r = Array.from(request);
  const write = r[10] === 1;
  const payload = write ? [] : data;
  const body = [0xaa, 0x55, 0x00, r[3], r[5], ADDR_PC, r[6], r[7], r[8], r[9], r[10], 0x00, r[12], r[13], r[14], r[15], ...u16le(payload.length), ...payload];
  return [...body, ...checksum(body)];
}

export const pctToLevel = (pct) => Math.round((Math.max(0, Math.min(100, pct)) / 100) * 255);
export const levelToPct = (level) => Math.round((level / 255) * 100);

export function cmdReadModelId() {
  return buildFrame({ address: REG.modelId, write: false, length: 2 });
}

export function cmdBrightness(level) {
  const v = Math.max(0, Math.min(255, Math.round(level)));
  return buildFrame({ address: REG.brightness, data: [v], dest: 0xff, devType: 0x01, port: 0xff, board: 0xffff });
}

export function cmdDisplayMode(modeId) {
  const mode = DISPLAY_MODES.find((m) => m.id === modeId);
  if (!mode) throw new Error(`Modo desconocido: ${modeId}`);
  return buildFrame({ address: REG.displayMode, data: [mode.code, 0x00] });
}

export function cmdTestPattern(code) {
  return buildFrame({ address: REG.displayMode, data: [0x06, code & 0xff] });
}

function presetFrame(op, index, extra = []) {
  const n = Math.max(0, Math.min(PRESET_COUNT - 1, index));
  return buildFrame({ address: REG.preset + op, data: [...extra, n] });
}

export const cmdPresetLoad = (index) => presetFrame(0x00, index);
export const cmdPresetSave = (index) => presetFrame(0x02, index);

export function cmdLayerSource(layer, slotCode) {
  const l = Math.max(0, Math.min(LAYER_COUNT - 1, layer));
  return buildFrame({ address: REG.layerSourceBase + l * REG.layerStride, data: [slotCode & 0xff, 0x00, 0x00] });
}

// Requiere enviar las tres tramas en orden, esperando respuesta válida de cada una.
export function cmdBackupMode(backup) {
  const v = backup ? 0x80 : 0x00;
  return [
    buildFrame({ address: REG.backupA, data: [v, v, v, v] }),
    buildFrame({ address: REG.backupB, data: [v, v, v, v] }),
    buildFrame({ address: REG.backupC, data: [v, v] }),
  ];
}

export function cmdReadInputs() {
  return buildFrame({ address: REG.inputInfo, write: false, length: 0x100 });
}

export function parseModelId(data) {
  if (!data || data.length < 2) return null;
  return readU16(data, 0);
}

const INPUT_BLOCK = 32;

// Bloques de 32 bytes por fuente: [1] entrelazado, [2] señal, [3-4] ancho, [5-6] alto, [7-8] periodo de cuadro en µs.
export function parseInputs(data) {
  const out = [];
  for (let i = 0; i * INPUT_BLOCK + 9 <= (data?.length || 0); i++) {
    const o = i * INPUT_BLOCK;
    const period = readU16(data, o + 7);
    out.push({
      index: i,
      interlaced: data[o + 1] === 1,
      signal: data[o + 2] === 1,
      width: readU16(data, o + 3),
      height: readU16(data, o + 5),
      fps: period ? Math.round((1e6 / period) * 100) / 100 : 0,
    });
  }
  return out;
}

export function formatInput(info) {
  if (!info.signal) return 'Sin señal';
  if (!info.width || !info.height) return 'Con señal';
  return `${info.width}×${info.height}${info.interlaced ? 'i' : 'p'}${info.fps ? ` @ ${info.fps} Hz` : ''}`;
}

// Traducción de acciones de alto nivel (UI y programación horaria) a tramas.
export function actionFrames(action) {
  switch (action?.type) {
    case 'brightness': return [cmdBrightness(pctToLevel(action.value))];
    case 'mode': return [cmdDisplayMode(action.value)];
    case 'pattern': return [cmdTestPattern(action.value)];
    case 'preset': return [cmdPresetLoad(action.value)];
    case 'preset-save': return [cmdPresetSave(action.value)];
    case 'source': return [cmdLayerSource(action.layer || 0, action.value)];
    case 'backup': return cmdBackupMode(!!action.value);
    default: throw new Error(`Acción desconocida: ${action?.type}`);
  }
}

export function describeAction(action) {
  switch (action?.type) {
    case 'brightness': return `Brillo ${action.value}%`;
    case 'mode': return DISPLAY_MODES.find((m) => m.id === action.value)?.label || action.value;
    case 'pattern': return `Patrón ${TEST_PATTERNS.find((p) => p.code === action.value)?.label || action.value}`;
    case 'preset': return `Preset ${action.value + 1}`;
    case 'preset-save': return `Guardar preset ${action.value + 1}`;
    case 'source': return `Capa ${(action.layer || 0) + 1} ← ${INPUT_SLOTS.find((s) => s.code === action.value)?.label || action.value}`;
    case 'backup': return action.value ? 'Modo backup' : 'Modo principal';
    default: return '—';
  }
}

export function isPrivateIPv4(host) {
  const m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(String(host || '').trim());
  if (!m) return false;
  const [a, b, c, d] = m.slice(1).map(Number);
  if ([a, b, c, d].some((x) => x > 255)) return false;
  return a === 10 || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 169 && b === 254) || a === 127;
}
