// Programación horaria estilo Taurus: reglas semanales que disparan acciones del protocolo.
// rule = { id, enabled, time: 'HH:MM', days: [0..6] (0 = domingo), action, deviceIds: ['*'] | [id...] }

export const DAY_LABELS = ['D', 'L', 'M', 'X', 'J', 'V', 'S'];
export const ALL_DAYS = [0, 1, 2, 3, 4, 5, 6];
export const SCHEDULE_MAX_LAG_MS = 15 * 60 * 1000;
const DAY_MS = 24 * 60 * 60 * 1000;

export function parseTime(s) {
  const m = /^(\d{1,2}):(\d{2})$/.exec(String(s || '').trim());
  if (!m) return null;
  const h = Number(m[1]);
  const min = Number(m[2]);
  return h < 24 && min < 60 ? h * 60 + min : null;
}

export const isValidTime = (s) => parseTime(s) !== null;

function occurrenceOn(rule, date) {
  const m = parseTime(rule.time);
  if (m === null || !(rule.days || []).includes(date.getDay())) return null;
  return new Date(date.getFullYear(), date.getMonth(), date.getDate(), Math.floor(m / 60), m % 60, 0, 0);
}

const active = (rules) => (rules || []).filter((r) => r && r.enabled !== false);

// Reglas cuya hora cae en (from, to]. Los huecos mayores a maxLagMs no se recuperan aquí (ver resumeActions).
export function dueRules(rules, from, to, maxLagMs = SCHEDULE_MAX_LAG_MS) {
  const start = Math.max(from.getTime(), to.getTime() - maxLagMs);
  const end = to.getTime();
  return active(rules).filter((r) => [new Date(start), to].some((d) => {
    const t = occurrenceOn(r, d)?.getTime();
    return t !== undefined && t > start && t <= end;
  }));
}

export function nextRun(rule, now) {
  for (let d = 0; d <= 7; d++) {
    const t = occurrenceOn(rule, new Date(now.getTime() + d * DAY_MS));
    if (t && t.getTime() > now.getTime()) return t;
  }
  return null;
}

export function lastRun(rule, now) {
  for (let d = 0; d <= 7; d++) {
    const t = occurrenceOn(rule, new Date(now.getTime() - d * DAY_MS));
    if (t && t.getTime() <= now.getTime()) return t;
  }
  return null;
}

export function targetsOf(rule, devices) {
  const ids = rule.deviceIds || [];
  return ids.includes('*') ? devices : devices.filter((d) => ids.includes(d.id));
}

const actionKey = (a) => (a.type === 'source' ? `source:${a.layer || 0}` : a.type === 'pattern' ? 'mode' : a.type);

// Estado que debería tener cada equipo ahora según la programación (para reponerlo tras un corte o reinicio).
export function resumeActions(rules, devices, now) {
  const latest = new Map();
  active(rules).forEach((rule) => {
    const at = lastRun(rule, now);
    if (!at) return;
    targetsOf(rule, devices).forEach((dev) => {
      const key = `${dev.id}|${actionKey(rule.action)}`;
      const prev = latest.get(key);
      if (!prev || prev.at < at) latest.set(key, { device: dev, action: rule.action, at, ruleId: rule.id });
    });
  });
  return [...latest.values()].sort((a, b) => a.at - b.at);
}

export function daysLabel(days) {
  const set = [...new Set(days || [])].sort();
  if (set.length === 7) return 'Todos los días';
  if (set.join() === '1,2,3,4,5') return 'Lun a Vie';
  if (set.join() === '0,6') return 'Fin de semana';
  return set.map((d) => DAY_LABELS[d]).join(' ') || 'Ningún día';
}
