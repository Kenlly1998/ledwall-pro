import { REG, DISPLAY_MODES, buildResponse, checksum } from './novastar.js';

const SIM_MODEL_ID = [0x0c, 0x62];
const SIM_INPUTS = [
  { signal: 1, width: 1920, height: 1080, period: 16667 },
  { signal: 1, width: 3840, height: 2160, period: 33333 },
  { signal: 0 },
  { signal: 0 },
  { signal: 1, width: 1920, height: 1080, period: 20000 },
];

function inputsBlock() {
  const data = Array(0x100).fill(0);
  SIM_INPUTS.forEach((s, i) => {
    const o = i * 32;
    data[o + 2] = s.signal;
    if (!s.signal) return;
    data[o + 3] = s.width & 0xff; data[o + 4] = s.width >> 8;
    data[o + 5] = s.height & 0xff; data[o + 6] = s.height >> 8;
    data[o + 7] = s.period & 0xff; data[o + 8] = s.period >> 8;
  });
  return data;
}

// Procesador virtual: responde como un VX1000 para probar la app y el puente sin hardware.
export function createSimulator() {
  const state = { brightness: 255, mode: 'normal', pattern: null, preset: null, backup: false, layers: [0, 1, 0] };

  function handle(request) {
    const r = Array.from(request);
    const len = r[16] | (r[17] << 8);
    const end = 18 + (r[10] === 1 ? len : 0);
    const [lo, hi] = checksum(r, 2, end);
    if (r[0] !== 0x55 || r[1] !== 0xaa || r[end] !== lo || r[end + 1] !== hi) return null;

    const address = (r[12] | (r[13] << 8) | (r[14] << 16) | (r[15] << 24)) >>> 0;
    const data = r.slice(18, end);
    if (r[10] !== 1) {
      if (address === REG.modelId) return buildResponse(r, SIM_MODEL_ID);
      if (address === REG.inputInfo) return buildResponse(r, inputsBlock());
      return buildResponse(r, Array(len).fill(0));
    }

    if (address === REG.brightness) state.brightness = data[0];
    else if (address === REG.displayMode) {
      if (data[0] === 0x06) { state.pattern = data[1]; state.mode = 'pattern'; }
      else { state.mode = DISPLAY_MODES.find((m) => m.code === data[0])?.id || state.mode; state.pattern = null; }
    } else if (address === REG.preset) state.preset = data[0];
    else if (address === REG.backupC) state.backup = data[0] === 0x80;
    else if (address >= REG.layerSourceBase && (address - REG.layerSourceBase) % REG.layerStride === 0) {
      state.layers[(address - REG.layerSourceBase) / REG.layerStride] = data[0];
    }
    return buildResponse(r);
  }

  return { state, handle };
}
