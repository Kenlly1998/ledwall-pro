#!/usr/bin/env node
// LED Wall Pro · Puente LAN para procesadores NovaStar (VX1000 / VX600 / VX16s / UHD Jr / MCTRL4K).
// Requiere Node 20.19+ o 22+. Sin dependencias.
//
//   node bridge/led-bridge.mjs                 escucha en :8787 y habla TCP 5200 con los equipos
//   node bridge/led-bridge.mjs --demo          simula procesadores (sin hardware)
//   PORT=9000 TOKEN=secreto node bridge/led-bridge.mjs
//
// La app se conecta a http://<IP-de-esta-PC>:8787. La programación horaria se ejecuta aquí 24/7.

import http from 'node:http';
import net from 'node:net';
import dgram from 'node:dgram';
import os from 'node:os';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  NOVA_TCP_PORT, NOVA_UDP_SEARCH_PORT, NOVA_SEARCH_REQUEST, NOVA_SEARCH_REPLY_PREFIX,
  extractFrame, parseResponse, fromHex, toHex, actionFrames, describeAction, isPrivateIPv4,
} from '../src/core/novastar.js';
import { createSimulator } from '../src/core/novastarSim.js';
import { dueRules, nextRun, resumeActions, targetsOf } from '../src/core/schedule.js';

const VERSION = '1.0.0';
const HTTP_PORT = Number(process.env.PORT || 8787);
const TOKEN = process.env.TOKEN || '';
const DEMO = process.argv.includes('--demo');
const ALLOWED_PORTS = (process.env.ALLOWED_PORTS || String(NOVA_TCP_PORT)).split(',').map(Number);
const REQUEST_TIMEOUT_MS = 2500;
const IDLE_CLOSE_MS = 60_000;
const TICK_MS = 10_000;
const MAX_BODY = 64 * 1024;
const MAX_FRAMES = 16;
const DATA_FILE = path.join(path.dirname(fileURLToPath(import.meta.url)), 'schedule.json');

const log = [];
function record(level, text, extra = {}) {
  const entry = { at: new Date().toISOString(), level, text, ...extra };
  log.unshift(entry);
  log.length = Math.min(log.length, 200);
  console.log(`[${entry.at.slice(11, 19)}] ${level.toUpperCase().padEnd(5)} ${text}`);
}

// ---------- Transporte TCP: una conexión persistente y una cola por equipo ----------

const sims = new Map();

class DeviceLink {
  constructor(host, port) {
    this.host = host;
    this.port = port;
    this.socket = null;
    this.buffer = [];
    this.pending = null;
    this.queue = Promise.resolve();
    this.idleTimer = null;
  }

  connect() {
    if (this.socket && !this.socket.destroyed) return Promise.resolve(this.socket);
    return new Promise((resolve, reject) => {
      const s = net.createConnection({ host: this.host, port: this.port });
      s.setNoDelay(true);
      const fail = (err) => { s.destroy(); reject(err); };
      s.setTimeout(REQUEST_TIMEOUT_MS, () => fail(new Error('Tiempo de conexión agotado')));
      s.once('error', fail);
      s.once('connect', () => {
        s.setTimeout(0);
        s.off('error', fail);
        s.on('error', (err) => { if (this.socket === s) this.drop(err); });
        s.on('close', () => { if (this.socket === s) this.drop(new Error('Conexión cerrada por el equipo')); });
        s.on('data', (chunk) => { if (this.socket === s) this.onData(chunk); });
        this.socket = s;
        this.buffer = [];
        resolve(s);
      });
    });
  }

  onData(chunk) {
    this.buffer.push(...chunk);
    const found = extractFrame(this.buffer);
    if (!found) return;
    this.buffer = found.rest;
    if (this.pending) {
      const { resolve, timer } = this.pending;
      clearTimeout(timer);
      this.pending = null;
      resolve(found.frame);
    }
  }

  drop(err) {
    if (this.socket) this.socket.destroy();
    this.socket = null;
    if (this.pending) {
      const { reject, timer } = this.pending;
      clearTimeout(timer);
      this.pending = null;
      reject(err);
    }
  }

  async transact(frame) {
    if (DEMO) {
      const key = `${this.host}:${this.port}`;
      if (!sims.has(key)) sims.set(key, createSimulator());
      await new Promise((r) => setTimeout(r, 15));
      const res = sims.get(key).handle(frame);
      if (!res) throw new Error('El simulador rechazó la trama');
      return res;
    }
    const s = await this.connect();
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending = null;
        this.drop(new Error('Sin respuesta del equipo'));
        reject(new Error('Sin respuesta del equipo'));
      }, REQUEST_TIMEOUT_MS);
      this.pending = { resolve, reject, timer };
      s.write(Buffer.from(frame));
    });
  }

  // Envía tramas en orden; cada una espera su respuesta antes de la siguiente.
  send(frames) {
    const run = async () => {
      clearTimeout(this.idleTimer);
      const out = [];
      try {
        for (const f of frames) out.push(await this.transact(f));
      } finally {
        this.idleTimer = setTimeout(() => this.drop(new Error('inactivo')), IDLE_CLOSE_MS);
      }
      return out;
    };
    const p = this.queue.then(run, run);
    this.queue = p.catch(() => {});
    return p;
  }
}

const links = new Map();
function linkFor(host, port = NOVA_TCP_PORT) {
  if (!isPrivateIPv4(host)) throw new Error(`IP no permitida (solo red local): ${host}`);
  if (!ALLOWED_PORTS.includes(port)) throw new Error(`Puerto no permitido: ${port}`);
  const key = `${host}:${port}`;
  if (!links.has(key)) links.set(key, new DeviceLink(host, port));
  return links.get(key);
}

async function sendFrames(host, port, frames) {
  const t0 = Date.now();
  const responses = await linkFor(host, port).send(frames);
  const parsed = responses.map(parseResponse);
  const bad = parsed.find((r) => !r.ok);
  if (bad) throw new Error(bad.error || 'Respuesta inválida');
  return { responses: responses.map(toHex), ms: Date.now() - t0 };
}

// ---------- Búsqueda UDP (puerto 3800) ----------

function broadcastAddresses() {
  const out = new Set(['255.255.255.255']);
  for (const list of Object.values(os.networkInterfaces())) {
    for (const ni of list || []) {
      if (ni.family !== 'IPv4' || ni.internal) continue;
      const ip = ni.address.split('.').map(Number);
      const mask = ni.netmask.split('.').map(Number);
      out.add(ip.map((b, i) => (b | (~mask[i] & 255))).join('.'));
    }
  }
  return [...out];
}

function discover(timeoutMs = 1500) {
  if (DEMO) return Promise.resolve([{ ip: '192.168.0.10', reply: `${NOVA_SEARCH_REPLY_PREFIX}App,0161 (demo)` }]);
  return new Promise((resolve) => {
    const found = new Map();
    const sock = dgram.createSocket({ type: 'udp4', reuseAddr: true });
    sock.on('message', (msg, rinfo) => {
      const text = msg.toString('latin1');
      if (text.startsWith(NOVA_SEARCH_REPLY_PREFIX)) found.set(rinfo.address, { ip: rinfo.address, reply: text });
    });
    sock.on('error', () => {});
    sock.bind(() => {
      sock.setBroadcast(true);
      const payload = Buffer.from(NOVA_SEARCH_REQUEST, 'latin1');
      broadcastAddresses().forEach((addr) => sock.send(payload, NOVA_UDP_SEARCH_PORT, addr, () => {}));
    });
    setTimeout(() => { sock.close(); resolve([...found.values()]); }, timeoutMs);
  });
}

// ---------- Programación horaria ----------

let schedule = { devices: [], rules: [], resumeOnStart: true, updatedAt: null };
try {
  schedule = { ...schedule, ...JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')) };
} catch { /* primera ejecución */ }

function saveSchedule() {
  fs.writeFileSync(DATA_FILE, JSON.stringify(schedule, null, 2));
}

async function runAction(device, action, origin) {
  try {
    const { ms } = await sendFrames(device.host, device.port || NOVA_TCP_PORT, actionFrames(action));
    record('ok', `${origin}: ${device.name || device.host} → ${describeAction(action)} (${ms} ms)`);
    return true;
  } catch (err) {
    record('error', `${origin}: ${device.name || device.host} → ${describeAction(action)}: ${err.message}`);
    return false;
  }
}

const RESUME_RETRY_MS = 30_000;
const RESUME_MAX_TRIES = 20;

// Tras un corte de energía el procesador suele arrancar después que el puente: se reintenta.
async function resumeState(attempt = 1) {
  const pending = resumeActions(schedule.rules, schedule.devices, new Date());
  if (!pending.length) return;
  if (attempt === 1) record('info', `Reponiendo ${pending.length} estado(s) de la programación tras el arranque`);
  const failed = [];
  for (const p of pending) if (!(await runAction(p.device, p.action, 'Reposición'))) failed.push(p);
  if (failed.length && attempt < RESUME_MAX_TRIES) setTimeout(() => resumeState(attempt + 1), RESUME_RETRY_MS);
}

let lastTick = new Date();
setInterval(() => {
  const now = new Date();
  dueRules(schedule.rules, lastTick, now).forEach((rule) => {
    targetsOf(rule, schedule.devices).forEach((dev) => runAction(dev, rule.action, 'Programación'));
  });
  lastTick = now;
}, TICK_MS);

setTimeout(() => { if (schedule.resumeOnStart) resumeState(); }, 5000);

// ---------- HTTP ----------

function cleanDevice(d) {
  return { id: String(d.id), name: String(d.name || ''), host: String(d.host || ''), port: Number(d.port) || NOVA_TCP_PORT };
}

function readJson(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > MAX_BODY) { reject(new Error('Cuerpo demasiado grande')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); } catch { reject(new Error('JSON inválido')); }
    });
  });
}

function reply(res, status, body) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, X-Bridge-Token',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, OPTIONS',
  });
  res.end(JSON.stringify(body));
}

const routes = {
  'GET /api/health': async () => ({
    ok: true, version: VERSION, demo: DEMO, time: new Date().toISOString(), uptimeS: Math.round(process.uptime()),
    devices: schedule.devices.length, rules: schedule.rules.length, auth: !!TOKEN,
  }),

  'POST /api/send': async (body) => {
    const frames = (body.frames || []).slice(0, MAX_FRAMES).map(fromHex);
    if (!frames.length) throw new Error('Sin tramas');
    if (frames.some((f) => f[0] !== 0x55 || f[1] !== 0xaa)) throw new Error('Trama sin cabecera 55 aa');
    return sendFrames(String(body.host || ''), Number(body.port) || NOVA_TCP_PORT, frames);
  },

  'GET /api/discover': async () => ({ devices: await discover() }),

  'GET /api/schedule': async () => schedule,

  'PUT /api/schedule': async (body) => {
    schedule = {
      devices: (body.devices || []).map(cleanDevice).filter((d) => isPrivateIPv4(d.host)),
      rules: Array.isArray(body.rules) ? body.rules : [],
      resumeOnStart: body.resumeOnStart !== false,
      updatedAt: new Date().toISOString(),
    };
    saveSchedule();
    const now = new Date();
    const upcoming = schedule.rules
      .filter((r) => r.enabled !== false)
      .map((r) => ({ id: r.id, at: nextRun(r, now)?.toISOString() || null }));
    record('info', `Programación actualizada: ${schedule.rules.length} regla(s), ${schedule.devices.length} equipo(s)`);
    return { ok: true, upcoming };
  },

  'GET /api/log': async () => ({ log }),
};

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') return reply(res, 204, {});
  const route = routes[`${req.method} ${req.url.split('?')[0]}`];
  if (!route) return reply(res, 404, { error: 'Ruta no encontrada' });
  if (TOKEN && req.headers['x-bridge-token'] !== TOKEN) return reply(res, 401, { error: 'Token inválido' });
  try {
    const body = req.method === 'POST' || req.method === 'PUT' ? await readJson(req) : {};
    reply(res, 200, await route(body));
  } catch (err) {
    reply(res, 400, { error: err.message });
  }
});

server.listen(HTTP_PORT, '0.0.0.0', () => {
  const ips = Object.values(os.networkInterfaces()).flat().filter((n) => n && n.family === 'IPv4' && !n.internal).map((n) => n.address);
  record('info', `Puente LED Wall Pro ${VERSION}${DEMO ? ' (DEMO)' : ''} escuchando en el puerto ${HTTP_PORT}`);
  ips.forEach((ip) => console.log(`        En la app usa: http://${ip}:${HTTP_PORT}`));
  if (TOKEN) console.log('        Token requerido (X-Bridge-Token).');
});
