#!/usr/bin/env bash
# Instala el puente LED Wall Pro como servicio systemd (Raspberry Pi OS, Debian, Ubuntu).
# Arranca con el equipo y se reinicia solo si falla.
#
#   sudo bash bridge/install-linux.sh [--port 8787] [--token xxx] [--demo]
#   sudo bash bridge/install-linux.sh --uninstall
set -euo pipefail

PORT=8787
TOKEN=""
DEMO=""
UNINSTALL=""
DIR=/opt/led-wall-bridge
SERVICE=led-wall-bridge

while [ $# -gt 0 ]; do
  case "$1" in
    --port) PORT="$2"; shift 2 ;;
    --token) TOKEN="$2"; shift 2 ;;
    --demo) DEMO="--demo"; shift ;;
    --uninstall) UNINSTALL=1; shift ;;
    *) echo "Opción desconocida: $1"; exit 1 ;;
  esac
done

[ "$(id -u)" -eq 0 ] || { echo "Ejecuta con sudo."; exit 1; }

if [ -n "$UNINSTALL" ]; then
  systemctl disable --now "$SERVICE" 2>/dev/null || true
  rm -f "/etc/systemd/system/$SERVICE.service"
  systemctl daemon-reload
  echo "Servicio eliminado. Datos conservados en $DIR"
  exit 0
fi

NODE="$(command -v node || true)"
[ -n "$NODE" ] || { echo "Falta Node.js 20+. En Raspberry Pi: curl -fsSL https://deb.nodesource.com/setup_20.x | sudo bash - && sudo apt install -y nodejs"; exit 1; }
MAJOR="$("$NODE" -p 'process.versions.node.split(".")[0]')"
[ "$MAJOR" -ge 18 ] || { echo "Node $MAJOR es muy antiguo: se necesita 18 o superior."; exit 1; }

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
[ -n "$TOKEN" ] || TOKEN="$(head -c 18 /dev/urandom | base64 | tr -dc 'A-Za-z0-9')"

id ledbridge >/dev/null 2>&1 || useradd --system --no-create-home --shell /usr/sbin/nologin ledbridge
mkdir -p "$DIR/bridge" "$DIR/src/core"
cp "$ROOT/bridge/led-bridge.mjs" "$DIR/bridge/"
cp "$ROOT"/src/core/*.js "$DIR/src/core/"
echo '{ "type": "module" }' > "$DIR/package.json"
chown -R ledbridge: "$DIR"

UNIT="/etc/systemd/system/$SERVICE.service"
cat > "$UNIT" <<EOF
[Unit]
Description=LED Wall Pro - puente LAN para procesadores NovaStar
After=network-online.target
Wants=network-online.target

[Service]
User=ledbridge
WorkingDirectory=$DIR
Environment=PORT=$PORT
Environment=TOKEN=$TOKEN
ExecStart=$NODE $DIR/bridge/led-bridge.mjs $DEMO
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
chmod 600 "$UNIT"

systemctl daemon-reload
systemctl enable "$SERVICE" >/dev/null
systemctl restart "$SERVICE"

OK=""
for _ in $(seq 1 15); do
  sleep 1
  if curl -fsS -H "X-Bridge-Token: $TOKEN" "http://127.0.0.1:$PORT/api/health" >/dev/null 2>&1; then OK=1; break; fi
done

echo
if [ -n "$OK" ]; then echo "Puente en marcha."; else echo "El puente no respondió: journalctl -u $SERVICE -n 50"; fi
echo "En la app (Control > Equipos > Puente LAN):"
for ip in $(hostname -I); do case "$ip" in *:*) ;; *) echo "  Dirección: $ip:$PORT" ;; esac; done
echo "  Token:     $TOKEN"
echo
echo "Registro en vivo: journalctl -u $SERVICE -f"
