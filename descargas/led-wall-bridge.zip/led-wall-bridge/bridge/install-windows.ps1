﻿# Instala el puente LED Wall Pro como tarea de Windows: arranca con el equipo (sin iniciar sesión),
# se reinicia si falla y abre el puerto en el firewall para redes privadas.
#
#   PowerShell como administrador, desde la carpeta del proyecto:
#   powershell -ExecutionPolicy Bypass -File bridge\install-windows.ps1 [-Port 8787] [-Token xxx] [-Demo]
#   powershell -ExecutionPolicy Bypass -File bridge\install-windows.ps1 -Uninstall [-Purge]

param(
  [int]$Port = 8787,
  [string]$Token = '',
  [switch]$Demo,
  [switch]$Uninstall,
  [switch]$Purge,
  [string]$InstallDir = (Join-Path $env:ProgramData 'LedWallBridge')
)

$ErrorActionPreference = 'Stop'
$TaskName = 'LED Wall Bridge'

$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  throw 'Abre PowerShell como administrador y vuelve a ejecutar el script.'
}

if ($Uninstall) {
  Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
  Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
  Remove-NetFirewallRule -DisplayName $TaskName -ErrorAction SilentlyContinue
  if ($Purge) { Remove-Item -Recurse -Force $InstallDir -ErrorAction SilentlyContinue }
  Write-Host "Puente desinstalado.$(if (-not $Purge) { " Datos conservados en $InstallDir" })"
  return
}

$node = (Get-Command node -ErrorAction SilentlyContinue).Source
if (-not $node) { throw 'No se encontró Node.js. Instálalo desde https://nodejs.org (LTS 20 o superior) y vuelve a ejecutar.' }
$version = [version]((& $node --version).TrimStart('v'))
if ($version.Major -lt 18) { throw "Node $version es muy antiguo: se necesita 18 o superior." }
if ($node -like "$env:TEMP*") { Write-Warning "Node está en una carpeta temporal ($node). Instálalo de forma permanente para que el servicio sobreviva a reinicios." }

if (-not $Token) {
  $bytes = New-Object byte[] 18
  [Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
  $Token = [Convert]::ToBase64String($bytes) -replace '[+/=]', ''
}

$root = Split-Path $PSScriptRoot -Parent
Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force -Path (Join-Path $InstallDir 'bridge'), (Join-Path $InstallDir 'src\core') | Out-Null
Copy-Item (Join-Path $root 'bridge\led-bridge.mjs') (Join-Path $InstallDir 'bridge') -Force
Copy-Item (Join-Path $root 'src\core\*.js') (Join-Path $InstallDir 'src\core') -Force
Set-Content -Path (Join-Path $InstallDir 'package.json') -Value '{ "type": "module" }' -Encoding ASCII

$runner = Join-Path $InstallDir 'run-bridge.cmd'
@(
  '@echo off',
  "cd /d `"$InstallDir`"",
  "set PORT=$Port",
  "set TOKEN=$Token",
  'if exist bridge.log move /y bridge.log bridge.prev.log >nul',
  "`"$node`" bridge\led-bridge.mjs$(if ($Demo) { ' --demo' }) > bridge.log 2>&1"
) | Set-Content -Path $runner -Encoding ASCII

# El token queda en run-bridge.cmd: solo SYSTEM y administradores pueden leerlo.
icacls $runner /inheritance:r /grant:r '*S-1-5-18:F' '*S-1-5-32-544:F' | Out-Null

$action = New-ScheduledTaskAction -Execute 'cmd.exe' -Argument "/c `"$runner`""
$trigger = New-ScheduledTaskTrigger -AtStartup
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable `
  -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero)
$taskUser = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Settings $settings -Principal $taskUser -Force | Out-Null

Remove-NetFirewallRule -DisplayName $TaskName -ErrorAction SilentlyContinue
New-NetFirewallRule -DisplayName $TaskName -Direction Inbound -Protocol TCP -LocalPort $Port -Action Allow -Profile Private, Domain | Out-Null

Start-ScheduledTask -TaskName $TaskName

$health = $null
foreach ($i in 1..15) {
  Start-Sleep -Seconds 1
  try { $health = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/api/health" -Headers @{ 'X-Bridge-Token' = $Token } -TimeoutSec 2; break } catch { }
}

$ips = Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } | Select-Object -ExpandProperty IPAddress
Write-Host ''
if ($health) { Write-Host "Puente v$($health.version) en marcha$(if ($health.demo) { ' (DEMO)' })." -ForegroundColor Green }
else { Write-Warning "El puente no respondió. Revisa $InstallDir\bridge.log" }
Write-Host 'En la app (Control > Equipos > Puente LAN):'
$ips | ForEach-Object { Write-Host "  Dirección: $($_):$Port" }
Write-Host "  Token:     $Token"
Write-Host ''
Write-Host "Arranca solo con Windows. Registro: $InstallDir\bridge.log"

$public = Get-NetConnectionProfile -ErrorAction SilentlyContinue | Where-Object NetworkCategory -eq 'Public'
if ($public) {
  Write-Warning "La red '$($public[0].Name)' está marcada como Pública y el firewall bloqueará al celular."
  Write-Host "  Cámbiala a Privada: Set-NetConnectionProfile -InterfaceAlias '$($public[0].InterfaceAlias)' -NetworkCategory Private"
}
